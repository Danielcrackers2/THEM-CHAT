#!/usr/bin/env bash
# MALIBA Release Keystore Generator by Daniel
echo "Generating MALIBA 25-Year Release Keystore..."
keytool -genkey -v \
  -keystore maliba-release.keystore \
  -alias maliba \
  -keyalg RSA \
  -keysize 2048 \
  -validity 9125 \
  -storepass maliba2026pass \
  -keypass maliba2026pass \
  -dname "CN=Daniel, OU=MALIBA, O=MALIBA App, L=Nairobi, ST=Nairobi, C=KE"
echo "Done! Keystore saved as maliba-release.keystore"
