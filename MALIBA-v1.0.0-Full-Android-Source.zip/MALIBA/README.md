# MALIBA - Connect Share Live (v1.0.0)

**Project Owner & Lead Developer:** Daniel  
**Package Name:** `com.daniel.maliba`  
**Target Platform:** Android (Min SDK 26, Target SDK 34)  
**Architecture:** MVVM Clean Architecture with Jetpack Compose & XML Layouts  

---

## 🌟 The Flagship Feature: 80MB & 60-Minute Status Videos
Unlike conventional messaging apps that cap video statuses at 30 seconds and 16MB, **MALIBA** empowers creators to post high-fidelity status videos up to:
- **Maximum File Size:** 80 Megabytes
- **Maximum Duration:** 60 Minutes (1 Hour)
- **Engine:** Mobile FFmpeg 4.4 LTS (libx264, CRF 23, preset veryfast, AAC 128kbps)
- **Adaptive Bitrate:** 500 kbps to 8.0 Mbps
- **Chunked Multipart Upload:** 5MB chunks with automatic 3x retry and offline WorkManager queue
- **Retention:** 24-hour auto-expiration

---

## 🛠 How to Build the APK in Android Studio

### Prerequisites
1. **Android Studio Hedgehog (2023.1.1)** or newer
2. **JDK 17** installed and configured in Android Studio (`Settings -> Build, Execution, Deployment -> Build Tools -> Gradle`)
3. **Android SDK 34** and Build Tools 34.0.0

### Step 1: Clone or Extract the Project
Extract the downloaded `MALIBA-1.0.0-Android-Project.zip` to your development folder.

### Step 2: Open in Android Studio
1. Launch Android Studio.
2. Select **Open** and navigate to the extracted `MALIBA` root directory.
3. Allow Gradle to sync dependencies automatically.

### Step 3: Generate Release Keystore
Run the following command in terminal:
```bash
keytool -genkey -v -keystore maliba-release.keystore -alias maliba -keyalg RSA -keysize 2048 -validity 9125 -storepass maliba2026pass -keypass maliba2026pass -dname "CN=Daniel, OU=MALIBA, O=MALIBA App, L=Nairobi, ST=Nairobi, C=KE"
```

### Step 4: Build Release APK or AAB
Run from the root terminal:
```bash
# Build Debug APK
./gradlew assembleDebug

# Build Release APK (Signed)
./gradlew assembleRelease

# Build Play Store App Bundle (AAB)
./gradlew bundleRelease
```

The generated artifacts will be located at:
- **Debug APK:** `app/build/outputs/apk/debug/app-debug.apk`
- **Release APK:** `app/build/outputs/apk/release/app-release.apk`
- **Play Store Bundle:** `app/build/outputs/bundle/release/app-release.aab`

---

## 🚀 How to Publish to Google Play Console
1. Log in to your [Google Play Console](https://play.google.com/console).
2. Create a new App: Name: **MALIBA**, Default Language: English, Free app.
3. Under **Production -> Releases**, create a new release and upload `app-release.aab`.
4. Copy the Privacy Policy, Terms of Service, and Store Listing copy from the legal documentation tab in MALIBA Studio.
5. Submit for review!
