# Terms of Service for MALIBA
**Last Updated:** January 15, 2026  
**Developer & Owner:** Daniel  

Welcome to MALIBA! By creating an account or using MALIBA, you agree to these terms:

1. **Acceptable Use:** You may not use MALIBA to transmit unlawful, defamatory, or abusive material.
2. **80MB Status Video Limit:** You agree not to circumvent the 80MB file size or 60-minute duration safeguards.
3. **Intellectual Property:** You retain ownership of videos and media you share. MALIBA claims no copyright over your statuses or messages.
4. **Account Suspension:** Violation of terms may result in immediate revocation of access.
