rootProject.name = "MALIBA"
include(":app")
