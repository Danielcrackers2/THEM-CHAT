package com.daniel.maliba.worker

import android.content.Context
import androidx.hilt.work.HiltWorker
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.daniel.maliba.data.repository.StatusRepository
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * MALIBA Chunked Multipart Status Video Uploader
 * Developed by Daniel.
 * 
 * Supports:
 * - Chunked multipart upload (5MB chunks)
 * - Automatic retry up to 3 times on network failure
 * - Offline queueing when disconnected
 * - 24-hour auto-delete scheduling
 */
@HiltWorker
class UploadWorker @AssistedInject constructor(
    @Assisted appContext: Context,
    @Assisted workerParams: WorkerParameters,
    private val statusRepository: StatusRepository
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val filePath = inputData.getString(KEY_FILE_PATH) ?: return@withContext Result.failure()
        val caption = inputData.getString(KEY_CAPTION) ?: ""
        val durationSec = inputData.getLong(KEY_DURATION_SEC, 0L)
        val file = File(filePath)

        if (!file.exists()) {
            return@withContext Result.failure()
        }

        try {
            // Upload in 5MB chunks to Node.js backend
            val success = statusRepository.uploadStatusVideoInChunks(
                file = file,
                caption = caption,
                durationSeconds = durationSec,
                onProgress = { percent ->
                    setProgressAsync(androidx.work.workDataOf("progress" to percent))
                }
            )

            if (success) {
                // Delete local temporary compressed cache
                file.delete()
                Result.success()
            } else {
                if (runAttemptCount < 3) {
                    Result.retry()
                } else {
                    // Save to pending queue for offline recovery
                    statusRepository.queueFailedUpload(filePath, caption, durationSec)
                    Result.failure()
                }
            }
        } catch (e: Exception) {
            if (runAttemptCount < 3) {
                Result.retry()
            } else {
                Result.failure()
            }
        }
    }

    companion object {
        const val KEY_FILE_PATH = "file_path"
        const val KEY_CAPTION = "caption"
        const val KEY_DURATION_SEC = "duration_sec"
    }
}