package com.daniel.maliba.ui.theme

import androidx.compose.ui.graphics.Color

// Daniel's specified MALIBA brand palette:
val MalibaPrimary = Color(0xFF075E54) // Dark Green
val MalibaPrimaryLight = Color(0xFF128C7E) // Teal Green
val MalibaAccent = Color(0xFF25D366) // WhatsApp Green
val MalibaBackground = Color(0xFFECE5DD) // Light Beige
val MalibaTextPrimary = Color(0xFF000000) // Black
val MalibaTextSecondary = Color(0xFF667781) // Grey
val MalibaError = Color(0xFFFF3B30) // Red

// Dark Mode Colors:
val MalibaDarkBackground = Color(0xFF0B141A)
val MalibaDarkSurface = Color(0xFF111B21)
val MalibaDarkTextPrimary = Color(0xFFE9EDEF)
val MalibaDarkTextSecondary = Color(0xFF8696A0)