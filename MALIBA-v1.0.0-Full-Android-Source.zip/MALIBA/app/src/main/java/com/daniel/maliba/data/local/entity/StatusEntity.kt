package com.daniel.maliba.data.local.entity

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Room Status Table
 * Columns: id, user_id, type, media_url, caption, size, duration, timestamp, expiry
 */
@Entity(tableName = "status")
data class StatusEntity(
    @PrimaryKey
    val id: String,

    @ColumnInfo(name = "user_id")
    val userId: String,

    val type: String, // "text", "photo", "video", "voice"

    @ColumnInfo(name = "media_url")
    val mediaUrl: String?,

    val caption: String?,

    val size: Long, // Size in bytes (up to 80MB)

    val duration: Long, // Duration in seconds (up to 3600 seconds)

    val timestamp: Long, // Creation epoch ms

    val expiry: Long // Expiry epoch ms (timestamp + 24 hours)
)