package com.daniel.maliba

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Configuration
import dagger.hilt.android.HiltAndroidApp
import net.sqlcipher.database.SQLiteDatabase
import javax.inject.Inject

/**
 * MALIBA Application entry point.
 * Developed by Daniel.
 * Handles Dependency Injection, Encrypted SQLCipher Init, and Notification Channels.
 */
@HiltAndroidApp
class MalibaApplication : Application(), Configuration.Provider {

    @Inject
    lateinit var workerFactory: HiltWorkerFactory

    override fun onCreate() {
        super.onCreate()
        
        // Initialize SQLCipher encrypted database libraries
        SQLiteDatabase.loadLibs(this)

        // Setup notification channels for calls, messages, and video uploads
        createNotificationChannels()
    }

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(NotificationManager::class.java)

            val messagesChannel = NotificationChannel(
                CHANNEL_MESSAGES,
                "Messages & Chats",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Incoming chat and group message alerts"
                enableVibration(true)
            }

            val uploadChannel = NotificationChannel(
                CHANNEL_UPLOADS,
                "Status Video Uploads (80MB / 60 Min)",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Progress for Mobile FFmpeg video compression and chunk uploads"
            }

            val callsChannel = NotificationChannel(
                CHANNEL_CALLS,
                "MALIBA Voice & Video Calls",
                NotificationManager.IMPORTANCE_MAX
            ).apply {
                description = "Incoming voice and video call notifications"
            }

            notificationManager?.createNotificationChannels(
                listOf(messagesChannel, uploadChannel, callsChannel)
            )
        }
    }

    companion object {
        const val CHANNEL_MESSAGES = "maliba_messages"
        const val CHANNEL_UPLOADS = "maliba_uploads"
        const val CHANNEL_CALLS = "maliba_calls"
    }
}