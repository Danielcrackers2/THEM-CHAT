package com.daniel.maliba.data.local

import androidx.room.Database
import androidx.room.RoomDatabase
import com.daniel.maliba.data.local.dao.*
import com.daniel.maliba.data.local.entity.*

/**
 * MALIBA Encrypted Room Database
 * Developed by Daniel.
 */
@Database(
    entities = [
        UserEntity::class,
        ChatEntity::class,
        MessageEntity::class,
        StatusEntity::class,
        CallEntity::class,
        GroupEntity::class,
        GroupMemberEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun chatDao(): ChatDao
    abstract fun messageDao(): MessageDao
    abstract fun statusDao(): StatusDao
    abstract fun callDao(): CallDao
    abstract fun groupDao(): GroupDao
}