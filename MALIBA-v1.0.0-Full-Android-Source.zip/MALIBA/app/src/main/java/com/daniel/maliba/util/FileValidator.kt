package com.daniel.maliba.util

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import java.io.File

/**
 * MALIBA File Validator
 * Developed by Daniel.
 * 
 * Enforces:
 * 1. Maximum file size: 80 MB
 * 2. Maximum duration: 60 minutes (3600 seconds)
 * 3. Supported formats: MP4, MOV, AVI, MKV, WEBM
 */
object FileValidator {

    const val MAX_FILE_SIZE_BYTES = 80L * 1024L * 1024L // 80 Megabytes
    const val MAX_DURATION_SECONDS = 60L * 60L // 60 Minutes (3600s)

    val SUPPORTED_EXTENSIONS = listOf("mp4", "mov", "avi", "mkv", "webm")

    sealed class ValidationResult {
        object Valid : ValidationResult()
        data class Error(val message: String) : ValidationResult()
    }

    data class VideoMetadata(
        val sizeBytes: Long,
        val sizeMb: Double,
        val durationSeconds: Long,
        val width: Int,
        val height: Int,
        val format: String
    )

    fun validateVideo(file: File): ValidationResult {
        // Step 2 & 4: Check file size
        if (file.length() > MAX_FILE_SIZE_BYTES) {
            val sizeMb = file.length().toDouble() / (1024.0 * 1024.0)
            return ValidationResult.Error(
                "Video exceeds 80 MB limit (${String.format("%.1f", sizeMb)} MB). Please trim or compress."
            )
        }

        // Step 6: Check format
        val extension = file.extension.lowercase()
        if (!SUPPORTED_EXTENSIONS.contains(extension)) {
            return ValidationResult.Error(
                "Unsupported format ($$extension). Use MP4, MOV, AVI, MKV, or WEBM."
            )
        }

        // Step 3 & 5: Check duration
        val durationSeconds = getVideoDuration(file.absolutePath)
        if (durationSeconds > MAX_DURATION_SECONDS) {
            val mins = durationSeconds / 60
            return ValidationResult.Error(
                "Video exceeds 1 hour limit ($mins minutes). Please shorten."
            )
        }

        return ValidationResult.Valid
    }

    fun getVideoDuration(filePath: String): Long {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(filePath)
            val time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val timeInMillis = time?.toLongOrNull() ?: 0L
            timeInMillis / 1000L
        } catch (e: Exception) {
            0L
        } finally {
            retriever.release()
        }
    }

    fun extractMetadata(context: Context, uri: Uri): VideoMetadata? {
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            val durationMs = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
            val height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
            val durationSec = durationMs / 1000L

            val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            val sizeBytes = pfd?.statSize ?: 0L
            pfd?.close()

            VideoMetadata(
                sizeBytes = sizeBytes,
                sizeMb = sizeBytes.toDouble() / (1024.0 * 1024.0),
                durationSeconds = durationSec,
                width = width,
                height = height,
                format = "mp4"
            )
        } catch (e: Exception) {
            null
        } finally {
            retriever.release()
        }
    }
}