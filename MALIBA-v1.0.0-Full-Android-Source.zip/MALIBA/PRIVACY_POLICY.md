# Privacy Policy for MALIBA
**Effective Date:** January 15, 2026  
**Developer:** Daniel  
**Application:** MALIBA (com.daniel.maliba)  

## 1. Information We Collect
- **Phone Number:** For OTP authentication and secure account creation.
- **Media Content:** Photos, voice notes, and videos uploaded to Chats and Status updates (including videos up to 80MB and 60 minutes).
- **Contacts:** To identify which of your contacts are already using MALIBA. Contact data is never sold or shared with third parties.
- **Microphone & Camera:** Exclusively when you take photos, record voice notes, or conduct WebRTC voice/video calls.

## 2. 24-Hour Status Expiration
All Status content (text, image, video up to 80MB) automatically expires and is permanently scrubbed from our production servers 24 hours after publication.

## 3. End-to-End Encryption
Messages and calls are encrypted using Signal Protocol and SQLCipher local database encryption.

## 4. Contact Developer
If you have questions regarding this policy, reach out to developer Daniel at `daniel@maliba.app`.
